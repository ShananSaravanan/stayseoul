﻿namespace StaySeoul_Session1
{
    partial class RegisterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.tnc_checkbox = new System.Windows.Forms.CheckBox();
            this.tnc = new System.Windows.Forms.LinkLabel();
            this.rpwdTxtField = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.fmlyMembers = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.femaleRadioBtn = new System.Windows.Forms.RadioButton();
            this.maleRadioBtn = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pwdTxtField = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.nameTxtField = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.usernameTxtField = new System.Windows.Forms.TextBox();
            this.birthdayPicker = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.regnloginBtn = new System.Windows.Forms.Button();
            this.returnBtn = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fmlyMembers)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tnc_checkbox);
            this.panel1.Controls.Add(this.tnc);
            this.panel1.Controls.Add(this.rpwdTxtField);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.fmlyMembers);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.femaleRadioBtn);
            this.panel1.Controls.Add(this.maleRadioBtn);
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Location = new System.Drawing.Point(22, 30);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(754, 359);
            this.panel1.TabIndex = 0;
            // 
            // tnc_checkbox
            // 
            this.tnc_checkbox.AutoSize = true;
            this.tnc_checkbox.Location = new System.Drawing.Point(40, 309);
            this.tnc_checkbox.Name = "tnc_checkbox";
            this.tnc_checkbox.Size = new System.Drawing.Size(243, 20);
            this.tnc_checkbox.TabIndex = 9;
            this.tnc_checkbox.Text = " I agree to the Terms and Conditions";
            this.tnc_checkbox.UseVisualStyleBackColor = true;
            // 
            // tnc
            // 
            this.tnc.AutoSize = true;
            this.tnc.Location = new System.Drawing.Point(403, 313);
            this.tnc.Name = "tnc";
            this.tnc.Size = new System.Drawing.Size(170, 16);
            this.tnc.TabIndex = 8;
            this.tnc.TabStop = true;
            this.tnc.Text = "View Terms and Conditions";
            this.tnc.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.tnc_LinkClicked);
            // 
            // rpwdTxtField
            // 
            this.rpwdTxtField.Location = new System.Drawing.Point(512, 232);
            this.rpwdTxtField.Name = "rpwdTxtField";
            this.rpwdTxtField.Size = new System.Drawing.Size(229, 22);
            this.rpwdTxtField.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(389, 235);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Retype Password :";
            // 
            // fmlyMembers
            // 
            this.fmlyMembers.Location = new System.Drawing.Point(594, 109);
            this.fmlyMembers.Name = "fmlyMembers";
            this.fmlyMembers.Size = new System.Drawing.Size(53, 22);
            this.fmlyMembers.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(403, 111);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(178, 16);
            this.label6.TabIndex = 4;
            this.label6.Text = "Number of Family Members :";
            // 
            // femaleRadioBtn
            // 
            this.femaleRadioBtn.AutoSize = true;
            this.femaleRadioBtn.Location = new System.Drawing.Point(487, 51);
            this.femaleRadioBtn.Name = "femaleRadioBtn";
            this.femaleRadioBtn.Size = new System.Drawing.Size(74, 20);
            this.femaleRadioBtn.TabIndex = 3;
            this.femaleRadioBtn.TabStop = true;
            this.femaleRadioBtn.Text = "Female";
            this.femaleRadioBtn.UseVisualStyleBackColor = true;
            // 
            // maleRadioBtn
            // 
            this.maleRadioBtn.AutoSize = true;
            this.maleRadioBtn.Location = new System.Drawing.Point(403, 51);
            this.maleRadioBtn.Name = "maleRadioBtn";
            this.maleRadioBtn.Size = new System.Drawing.Size(58, 20);
            this.maleRadioBtn.TabIndex = 2;
            this.maleRadioBtn.TabStop = true;
            this.maleRadioBtn.Text = "Male";
            this.maleRadioBtn.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.88461F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 72.11539F));
            this.tableLayoutPanel1.Controls.Add(this.pwdTxtField, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.nameTxtField, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.usernameTxtField, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.birthdayPicker, 1, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(34, 32);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(349, 242);
            this.tableLayoutPanel1.TabIndex = 1;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // pwdTxtField
            // 
            this.pwdTxtField.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pwdTxtField.Location = new System.Drawing.Point(100, 200);
            this.pwdTxtField.Name = "pwdTxtField";
            this.pwdTxtField.Size = new System.Drawing.Size(246, 22);
            this.pwdTxtField.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 180);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 62);
            this.label5.TabIndex = 6;
            this.label5.Text = "Password";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 120);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 60);
            this.label4.TabIndex = 4;
            this.label4.Text = "Birthday: ";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nameTxtField
            // 
            this.nameTxtField.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nameTxtField.Location = new System.Drawing.Point(100, 79);
            this.nameTxtField.Name = "nameTxtField";
            this.nameTxtField.Size = new System.Drawing.Size(246, 22);
            this.nameTxtField.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 60);
            this.label3.TabIndex = 2;
            this.label3.Text = "Full Name :";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 60);
            this.label2.TabIndex = 0;
            this.label2.Text = "Username :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // usernameTxtField
            // 
            this.usernameTxtField.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.usernameTxtField.Location = new System.Drawing.Point(100, 19);
            this.usernameTxtField.Name = "usernameTxtField";
            this.usernameTxtField.Size = new System.Drawing.Size(246, 22);
            this.usernameTxtField.TabIndex = 1;
            // 
            // birthdayPicker
            // 
            this.birthdayPicker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.birthdayPicker.Location = new System.Drawing.Point(100, 139);
            this.birthdayPicker.Name = "birthdayPicker";
            this.birthdayPicker.Size = new System.Drawing.Size(246, 22);
            this.birthdayPicker.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Your Information";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // regnloginBtn
            // 
            this.regnloginBtn.Location = new System.Drawing.Point(439, 405);
            this.regnloginBtn.Name = "regnloginBtn";
            this.regnloginBtn.Size = new System.Drawing.Size(164, 33);
            this.regnloginBtn.TabIndex = 1;
            this.regnloginBtn.Text = "Register and Login";
            this.regnloginBtn.UseVisualStyleBackColor = true;
            this.regnloginBtn.Click += new System.EventHandler(this.regnloginBtn_Click);
            // 
            // returnBtn
            // 
            this.returnBtn.Location = new System.Drawing.Point(616, 405);
            this.returnBtn.Name = "returnBtn";
            this.returnBtn.Size = new System.Drawing.Size(160, 33);
            this.returnBtn.TabIndex = 2;
            this.returnBtn.Text = "Return to Login Form";
            this.returnBtn.UseVisualStyleBackColor = true;
            this.returnBtn.Click += new System.EventHandler(this.returnBtn_Click);
            // 
            // RegisterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.returnBtn);
            this.Controls.Add(this.regnloginBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Name = "RegisterForm";
            this.Text = "Seoul Stay - Create Account";
            this.Load += new System.EventHandler(this.RegisterForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fmlyMembers)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox rpwdTxtField;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown fmlyMembers;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton femaleRadioBtn;
        private System.Windows.Forms.RadioButton maleRadioBtn;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox pwdTxtField;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox nameTxtField;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox usernameTxtField;
        private System.Windows.Forms.DateTimePicker birthdayPicker;
        private System.Windows.Forms.CheckBox tnc_checkbox;
        private System.Windows.Forms.LinkLabel tnc;
        private System.Windows.Forms.Button regnloginBtn;
        private System.Windows.Forms.Button returnBtn;
    }
}