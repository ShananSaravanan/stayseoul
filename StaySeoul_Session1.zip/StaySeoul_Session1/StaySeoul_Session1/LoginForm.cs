﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaySeoul_Session1
{
    
    public partial class LoginForm : Form
    {
        public static string userID = "";

        public LoginForm()
        {
            
            
            InitializeComponent();

        }
        Session1Entities ent = new Session1Entities();
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void show_pwd_CheckedChanged(object sender, EventArgs e)
        {
            if (show_pwd.Checked)
            {
                passwordField.UseSystemPasswordChar = false;
            }
            else
            {
                passwordField.UseSystemPasswordChar=true;
            }
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(empIDField.Text) == true && string.IsNullOrEmpty(userIDField.Text) == false)
                {
                    var found = ent.Users.Where(x => x.Username == userIDField.Text && x.Password == passwordField.Text && x.UserTypeID == 2).FirstOrDefault();
                    if (found != null)
                    {
                        MessageBox.Show("Login Successfull!", "User Log In");
                        var u = ent.Users.Where(x => x.Username == userIDField.Text);
                        userID = u.Select(x => x.ID).FirstOrDefault().ToString();
                        Menu f2 = new Menu();
                        f2.Show();
                        if (sign_in.Checked)
                        {
                            File.WriteAllText("session.txt", "");
                            File.WriteAllText("session.txt", userIDField.Text);
                        }
                        else
                        {
                            File.WriteAllText("session.txt","");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid Username or Password", "User Log In");
                    }

                }
                else if (string.IsNullOrEmpty(empIDField.Text) == false && string.IsNullOrEmpty(userIDField.Text) == false)
                {
                    var found = ent.Users.Where(x => x.Username == empIDField.Text && x.Password == passwordField.Text && x.UserTypeID == 1).FirstOrDefault();
                    if (found != null)
                    {
                        var found2 = ent.Users.Where(u => u.Username == userIDField.Text && u.UserTypeID == 2).FirstOrDefault();
                        if (found2 != null)
                        {
                            MessageBox.Show("Login Successfull", "Employee Login");
                            var u = ent.Users.Where(x => x.Username == userIDField.Text);
                            userID = u.Select(x => x.ID).FirstOrDefault().ToString();
                            Menu f2 = new Menu();
                            f2.Show();
                            if (sign_in.Checked)
                            {
                                File.WriteAllText("session.txt", "");
                                File.WriteAllText("session.txt", userIDField.Text);
                            }
                            else
                            {
                                File.WriteAllText("session.txt", "");
                            }
                        }
                        else
                        {
                            MessageBox.Show("User ID not found", "Employee Login");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid Employee Credentials!", "Employee Login");
                    }

                }
                else if (string.IsNullOrEmpty(empIDField.Text) == false && string.IsNullOrEmpty(userIDField.Text) == true)
                {
                    MessageBox.Show("User Field cannot be empty!", "Employee Login");
                }
                else
                {
                    MessageBox.Show("User Field or Employee Field has to be filled in");
                }
            }
            catch(Exception E)
            {
                MessageBox.Show(E.ToString());
            }

            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string login = File.ReadAllText("session.txt");

            if (string.IsNullOrEmpty(login) == false)
            {
                var u = ent.Users.Where(x => x.Username == login);
                userID = u.Select(x => x.ID).FirstOrDefault().ToString();
                this.Hide();
                Menu m = new Menu();
                m.Show();
            }
            

            if (show_pwd.Checked)
            {
                passwordField.UseSystemPasswordChar = false;
            }
            else
            {
                passwordField.UseSystemPasswordChar = true;
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            RegisterForm rf = new RegisterForm();
            this.Hide();
            rf.Show();
            
        }

        private void sign_in_CheckedChanged(object sender, EventArgs e)
        {
            
        }
    }
}
