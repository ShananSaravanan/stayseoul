﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaySeoul_Session1
{
    public partial class RegisterForm : Form
    {
        public static string userID = "";
        Session1Entities ent = new Session1Entities();
        public RegisterForm()
        {
            InitializeComponent();
        }
        public bool checkEmptyFields()
        {
            bool isEmpty = true;
            if(string.IsNullOrEmpty(usernameTxtField.Text) == true || string.IsNullOrEmpty(nameTxtField.Text) == true ||
                string.IsNullOrEmpty(pwdTxtField.Text) == true || string.IsNullOrEmpty(rpwdTxtField.Text) == true)
            {
                isEmpty = true;
                MessageBox.Show("All field are required to be filled in!");
            }
            else
            {
                isEmpty = false;
            }
            return isEmpty;
        }
        public bool checkPasswordMatch()
        {
            bool isPasswordMatch = false;
            if(string.Equals(pwdTxtField.Text,rpwdTxtField.Text))
            {
                isPasswordMatch = true;
            }
            else
            {
                isPasswordMatch = false;
                MessageBox.Show("Password does not match!");
            }
            return isPasswordMatch;
        }
        public bool checkPasswordLength()
        {
            bool strength = false;
            if(pwdTxtField.Text.Length < 5)
            {
                strength = false;
                MessageBox.Show("Password length must be more than 5 characters");
            }
            else
            {
                strength = true;
            }
            return strength;
        }
        public bool checkBoxes()
        {
            bool unChecked = true;
            if(tnc_checkbox.Checked == false)
            {
                unChecked = true;
                MessageBox.Show("Please agree to the Terms and Conditions");
            }
            else
            {
                unChecked = false;
            }
            return unChecked;
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void returnBtn_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
            
        }
        private void RegisterForm_Load(object sender, EventArgs e)
        {
            pwdTxtField.UseSystemPasswordChar = true;
            rpwdTxtField.UseSystemPasswordChar = true;
            tnc_checkbox.Enabled = false;
            birthdayPicker.MaxDate = DateTime.Now;
            maleRadioBtn.Checked = true;
        }

        private void tnc_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string tnc_file = "Terms.txt";
            Process.Start(tnc_file);
            tnc_checkbox.Enabled = true;
        }

        private void regnloginBtn_Click(object sender, EventArgs e)
        {
            if(!checkEmptyFields() && !checkBoxes() && checkPasswordMatch() && checkPasswordLength())
            {
                var ufound = ent.Users.Where(x => x.Username == usernameTxtField.Text ).FirstOrDefault();
                var nfound = ent.Users.Where(y => y.FullName == nameTxtField.Text).FirstOrDefault();
                if(ufound == null && nfound == null)
                {
                    var count = ent.Users.Count();
                    count = count + 2;
                    Guid guid = Guid.NewGuid();
                    bool gender = true;
                    if (maleRadioBtn.Checked)
                    {
                        gender = false;
                    }
                    else
                    {
                       gender = true;
                    }
                    var userDetails = new User {
                        ID = count,
                        GUID = guid,
                        UserTypeID = 2,
                        Username = usernameTxtField.Text,
                        Password = pwdTxtField.Text,
                        FullName = nameTxtField.Text,
                        Gender = gender,
                        BirthDate = birthdayPicker.Value,
                        FamilyCount = (int)fmlyMembers.Value,

                    };
                    try
                    {
                        ent.Users.Add(userDetails);
                        ent.SaveChanges();
                        MessageBox.Show("Registration Successfull!","Registration");
                        var u = ent.Users.Where(x => x.Username == usernameTxtField.Text);
                        userID = u.Select(x => x.ID).FirstOrDefault().ToString();
                        Menu m = new Menu();
                        m.Show();
                        this.Hide();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                }
                else if(nfound != null)
                {
                    MessageBox.Show("The full name entered is already in the database","Duplicate Entry");
                }
                else if (ufound != null)
                {
                    MessageBox.Show("The username entered is already in the database","Duplicate Entry");
                }
            }
        }
    }
}
