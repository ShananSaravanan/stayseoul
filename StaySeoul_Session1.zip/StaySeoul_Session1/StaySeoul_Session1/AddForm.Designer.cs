﻿namespace StaySeoul_Session1
{
    partial class AddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.nextBtn = new System.Windows.Forms.Button();
            this.amenitiesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.session1DataSet = new StaySeoul_Session1.Session1DataSet();
            this.max = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.min = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.rulesTxtField = new System.Windows.Forms.RichTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.descTxtField = new System.Windows.Forms.RichTextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label9 = new System.Windows.Forms.Label();
            this.eAddressTxtField = new System.Windows.Forms.RichTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.aAdressTxtField = new System.Windows.Forms.TextBox();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label7 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nBathRooms = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.nBedRooms = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.nBeds = new System.Windows.Forms.NumericUpDown();
            this.capacity = new System.Windows.Forms.NumericUpDown();
            this.finishBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.amenitiesTableAdapter = new StaySeoul_Session1.Session1DataSetTableAdapters.AmenitiesTableAdapter();
            this.label3 = new System.Windows.Forms.Label();
            this.chkBox = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.amenityRow = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label14 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.titleTxtField = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.typeCmbBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.itemTypesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.itemTypesTableAdapter = new StaySeoul_Session1.Session1DataSetTableAdapters.ItemTypesTableAdapter();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.areasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.areasTableAdapter = new StaySeoul_Session1.Session1DataSetTableAdapters.AreasTableAdapter();
            this.attractionsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.attractionsTableAdapter = new StaySeoul_Session1.Session1DataSetTableAdapters.AttractionsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.amenitiesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.session1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.max)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.min)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nBathRooms)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nBedRooms)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nBeds)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.capacity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.itemTypesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.areasBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.attractionsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // nextBtn
            // 
            this.nextBtn.Location = new System.Drawing.Point(576, 460);
            this.nextBtn.Name = "nextBtn";
            this.nextBtn.Size = new System.Drawing.Size(88, 37);
            this.nextBtn.TabIndex = 5;
            this.nextBtn.Text = "Next";
            this.nextBtn.UseVisualStyleBackColor = true;
            this.nextBtn.Click += new System.EventHandler(this.nextBtn_Click);
            // 
            // amenitiesBindingSource
            // 
            this.amenitiesBindingSource.DataMember = "Amenities";
            this.amenitiesBindingSource.DataSource = this.session1DataSet;
            // 
            // session1DataSet
            // 
            this.session1DataSet.DataSetName = "Session1DataSet";
            this.session1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // max
            // 
            this.max.Location = new System.Drawing.Point(438, 383);
            this.max.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.max.Name = "max";
            this.max.Size = new System.Drawing.Size(56, 22);
            this.max.TabIndex = 24;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(366, 386);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 16);
            this.label13.TabIndex = 23;
            this.label13.Text = "Maximum :";
            // 
            // min
            // 
            this.min.Location = new System.Drawing.Point(289, 383);
            this.min.Name = "min";
            this.min.Size = new System.Drawing.Size(58, 22);
            this.min.TabIndex = 22;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(217, 386);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 16);
            this.label12.TabIndex = 21;
            this.label12.Text = "Minimum :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(23, 386);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(169, 16);
            this.label11.TabIndex = 20;
            this.label11.Text = "Reservation Time (Nights) :";
            // 
            // rulesTxtField
            // 
            this.rulesTxtField.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rulesTxtField.Location = new System.Drawing.Point(167, 310);
            this.rulesTxtField.Name = "rulesTxtField";
            this.rulesTxtField.Size = new System.Drawing.Size(598, 34);
            this.rulesTxtField.TabIndex = 19;
            this.rulesTxtField.Text = "";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(21, 313);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 16);
            this.label10.TabIndex = 18;
            this.label10.Text = "Host Rules :";
            // 
            // descTxtField
            // 
            this.descTxtField.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.descTxtField.Location = new System.Drawing.Point(167, 259);
            this.descTxtField.Name = "descTxtField";
            this.descTxtField.Size = new System.Drawing.Size(598, 34);
            this.descTxtField.TabIndex = 17;
            this.descTxtField.Text = "";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(8, 12);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(511, 16);
            this.label15.TabIndex = 0;
            this.label15.Text = "Specify the distance from each close by attraction and the time it  takes to get " +
    "to them :";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "By Car (minutes)";
            this.Column5.MinimumWidth = 6;
            this.Column5.Name = "Column5";
            this.Column5.Width = 125;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "On Foot (minutes)";
            this.Column4.MinimumWidth = 6;
            this.Column4.Name = "Column4";
            this.Column4.Width = 120;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Distance (km)";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.Width = 120;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(21, 262);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 16);
            this.label9.TabIndex = 16;
            this.label9.Text = "Description :";
            // 
            // eAddressTxtField
            // 
            this.eAddressTxtField.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.eAddressTxtField.Location = new System.Drawing.Point(167, 209);
            this.eAddressTxtField.Name = "eAddressTxtField";
            this.eAddressTxtField.Size = new System.Drawing.Size(598, 34);
            this.eAddressTxtField.TabIndex = 15;
            this.eAddressTxtField.Text = "";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(21, 212);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 16);
            this.label8.TabIndex = 14;
            this.label8.Text = "Exact Address :";
            // 
            // aAdressTxtField
            // 
            this.aAdressTxtField.Location = new System.Drawing.Point(167, 169);
            this.aAdressTxtField.Name = "aAdressTxtField";
            this.aAdressTxtField.Size = new System.Drawing.Size(598, 22);
            this.aAdressTxtField.TabIndex = 13;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Area";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 150;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 172);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(143, 16);
            this.label7.TabIndex = 12;
            this.label7.Text = "Approximate Address :";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            this.dataGridView2.Location = new System.Drawing.Point(8, 43);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(776, 317);
            this.dataGridView2.TabIndex = 1;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Attraction";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 150;
            // 
            // nBathRooms
            // 
            this.nBathRooms.Location = new System.Drawing.Point(720, 73);
            this.nBathRooms.Name = "nBathRooms";
            this.nBathRooms.Size = new System.Drawing.Size(47, 22);
            this.nBathRooms.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(569, 75);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(145, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = "Number Of Bathrooms :";
            // 
            // nBedRooms
            // 
            this.nBedRooms.Location = new System.Drawing.Point(500, 73);
            this.nBedRooms.Name = "nBedRooms";
            this.nBedRooms.Size = new System.Drawing.Size(47, 22);
            this.nBedRooms.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(351, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(143, 16);
            this.label5.TabIndex = 8;
            this.label5.Text = "Number Of Bedrooms :";
            // 
            // nBeds
            // 
            this.nBeds.Location = new System.Drawing.Point(282, 73);
            this.nBeds.Name = "nBeds";
            this.nBeds.Size = new System.Drawing.Size(47, 22);
            this.nBeds.TabIndex = 7;
            // 
            // capacity
            // 
            this.capacity.Location = new System.Drawing.Point(88, 73);
            this.capacity.Name = "capacity";
            this.capacity.Size = new System.Drawing.Size(47, 22);
            this.capacity.TabIndex = 6;
            // 
            // finishBtn
            // 
            this.finishBtn.Location = new System.Drawing.Point(687, 460);
            this.finishBtn.Name = "finishBtn";
            this.finishBtn.Size = new System.Drawing.Size(109, 37);
            this.finishBtn.TabIndex = 6;
            this.finishBtn.Text = "Close / Finish";
            this.finishBtn.UseVisualStyleBackColor = true;
            this.finishBtn.Click += new System.EventHandler(this.finishBtn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(164, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "Number Of Beds :";
            // 
            // amenitiesTableAdapter
            // 
            this.amenitiesTableAdapter.ClearBeforeFill = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Capacity :";
            // 
            // chkBox
            // 
            this.chkBox.FalseValue = "false";
            this.chkBox.HeaderText = "";
            this.chkBox.MinimumWidth = 6;
            this.chkBox.Name = "chkBox";
            this.chkBox.TrueValue = "true";
            this.chkBox.Width = 125;
            // 
            // amenityRow
            // 
            this.amenityRow.HeaderText = "Amenity";
            this.amenityRow.MinimumWidth = 6;
            this.amenityRow.Name = "amenityRow";
            this.amenityRow.ReadOnly = true;
            this.amenityRow.Width = 125;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(32, 24);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(182, 16);
            this.label14.TabIndex = 1;
            this.label14.Text = "Choose Available Amenities :";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.amenityRow,
            this.chkBox});
            this.dataGridView1.Location = new System.Drawing.Point(35, 62);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(367, 278);
            this.dataGridView1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.dataGridView1);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 425);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Amenities";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // titleTxtField
            // 
            this.titleTxtField.Location = new System.Drawing.Point(411, 18);
            this.titleTxtField.Name = "titleTxtField";
            this.titleTxtField.Size = new System.Drawing.Size(356, 22);
            this.titleTxtField.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(366, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Title :";
            // 
            // typeCmbBox
            // 
            this.typeCmbBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.itemTypesBindingSource, "Name", true));
            this.typeCmbBox.DataSource = this.itemTypesBindingSource;
            this.typeCmbBox.DisplayMember = "Name";
            this.typeCmbBox.FormattingEnabled = true;
            this.typeCmbBox.Location = new System.Drawing.Point(88, 18);
            this.typeCmbBox.Name = "typeCmbBox";
            this.typeCmbBox.Size = new System.Drawing.Size(249, 24);
            this.typeCmbBox.TabIndex = 1;
            this.typeCmbBox.ValueMember = "ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Type :";
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(687, 460);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(109, 37);
            this.cancelBtn.TabIndex = 7;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.comboBox1);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.max);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.min);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.rulesTxtField);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.descTxtField);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.eAddressTxtField);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.aAdressTxtField);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.nBathRooms);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.nBedRooms);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.nBeds);
            this.tabPage1.Controls.Add(this.capacity);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.titleTxtField);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.typeCmbBox);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 425);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Listing Details";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dataGridView2);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(792, 425);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Distance To Attraction";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 454);
            this.tabControl1.TabIndex = 4;
            this.tabControl1.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl1_Selecting);
            // 
            // itemTypesBindingSource
            // 
            this.itemTypesBindingSource.DataMember = "ItemTypes";
            this.itemTypesBindingSource.DataSource = this.session1DataSet;
            // 
            // itemTypesTableAdapter
            // 
            this.itemTypesTableAdapter.ClearBeforeFill = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(23, 132);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(45, 16);
            this.label16.TabIndex = 25;
            this.label16.Text = "Area : ";
            // 
            // comboBox1
            // 
            this.comboBox1.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.areasBindingSource, "Name", true));
            this.comboBox1.DataSource = this.areasBindingSource;
            this.comboBox1.DisplayMember = "Name";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(167, 129);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(220, 24);
            this.comboBox1.TabIndex = 26;
            this.comboBox1.ValueMember = "ID";
            // 
            // areasBindingSource
            // 
            this.areasBindingSource.DataMember = "Areas";
            this.areasBindingSource.DataSource = this.session1DataSet;
            // 
            // areasTableAdapter
            // 
            this.areasTableAdapter.ClearBeforeFill = true;
            // 
            // attractionsBindingSource
            // 
            this.attractionsBindingSource.DataMember = "Attractions";
            this.attractionsBindingSource.DataSource = this.session1DataSet;
            // 
            // attractionsTableAdapter
            // 
            this.attractionsTableAdapter.ClearBeforeFill = true;
            // 
            // AddForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 509);
            this.Controls.Add(this.nextBtn);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.finishBtn);
            this.Name = "AddForm";
            this.Text = "Stay Seoul - Add / Edit Listing ";
            this.Load += new System.EventHandler(this.AddForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.amenitiesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.session1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.max)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.min)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nBathRooms)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nBedRooms)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nBeds)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.capacity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.itemTypesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.areasBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.attractionsBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button nextBtn;
        private System.Windows.Forms.BindingSource amenitiesBindingSource;
        private Session1DataSet session1DataSet;
        private System.Windows.Forms.NumericUpDown max;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown min;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RichTextBox rulesTxtField;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RichTextBox descTxtField;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RichTextBox eAddressTxtField;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox aAdressTxtField;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.NumericUpDown nBathRooms;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown nBedRooms;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nBeds;
        private System.Windows.Forms.NumericUpDown capacity;
        private System.Windows.Forms.Button finishBtn;
        private System.Windows.Forms.Label label4;
        private Session1DataSetTableAdapters.AmenitiesTableAdapter amenitiesTableAdapter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridViewCheckBoxColumn chkBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn amenityRow;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox titleTxtField;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox typeCmbBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.BindingSource itemTypesBindingSource;
        private Session1DataSetTableAdapters.ItemTypesTableAdapter itemTypesTableAdapter;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.BindingSource areasBindingSource;
        private Session1DataSetTableAdapters.AreasTableAdapter areasTableAdapter;
        private System.Windows.Forms.BindingSource attractionsBindingSource;
        private Session1DataSetTableAdapters.AttractionsTableAdapter attractionsTableAdapter;
    }
}