﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaySeoul_Session1
{
    public partial class Menu : Form
    {
        Session1Entities ent = new Session1Entities();
        public static string userID = "";
        public static long itemID;
        public static string propertyType ="";
        public Menu()
        {
            InitializeComponent();
        }

        private void Menu_Load(object sender, EventArgs e)
        {
            
            if (string.IsNullOrEmpty(RegisterForm.userID) == true)
            {
                userID = LoginForm.userID;
            }
            else
            {
                userID = RegisterForm.userID;
            }
            var u =(from i in ent.Items join a in ent.Areas on i.AreaID 
                    equals a.ID join b in ent.ItemTypes on i.ItemTypeID equals 
                    b.ID select new
                    {
                    i.Title,
                    i.Capacity,
                    a.Name,
                    itemname = b.Name
                    }
                    
                    );
            foreach (var item in u)
            {
                
                this.dataGridView1.Rows.Add(item.Title,item.Capacity,item.Name,item.itemname);

            }
           
            var o = (from i in ent.Items
                     join a in ent.Areas on i.AreaID equals a.ID
                     join b in ent.ItemTypes on i.ItemTypeID equals b.ID where i.UserID.ToString().Equals(userID)
                     select new
                     {
                         i.Title,
                         i.Capacity,
                         a.Name,
                         itemname = b.Name
                     }

                    );
            foreach (var item in o)
            {
                this.dataGridView2.Rows.Add(item.Title, item.Capacity, item.Name, item.itemname,"Edit Details");
                
            }
            
            foreach (DataGridViewRow r in dataGridView2.Rows)
            {
                DataGridViewLinkCell lc = new DataGridViewLinkCell();
                lc.Value = r.Cells[4].Value;
                dataGridView2[4, r.Index] = lc;
               
            }
            
            totalItemsLbl.Text = dataGridView1.Rows.Count.ToString() + " items found.";

        }

       

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
            var u = (from i in ent.Items
                     join a in ent.Areas on i.AreaID equals a.ID
                     join b in ent.ItemTypes on i.ItemTypeID equals b.ID where i.Title.StartsWith(textBox1.Text)
                     select new
                     {
                         i.Title,
                         i.Capacity,
                         a.Name,
                         itemname = b.Name
                     }

                    );
            dataGridView1.Rows.Clear();

            
            foreach (var item in u)
            {
                this.dataGridView1.Rows.Add(item.Title, item.Capacity, item.Name, item.itemname);
            }
            
            totalItemsLbl.Text = dataGridView1.Rows.Count.ToString() + " items found.";
        }


        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(tabControl1.SelectedTab == tabControl1.TabPages["tabPage1"])
            {
                totalItemsLbl.Text = dataGridView1.Rows.Count.ToString() + " items found.";
            }
            else
            {
                totalItemsLbl.Text = dataGridView2.Rows.Count.ToString() + " items found.";
            }
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
            foreach (DataGridViewRow r in dataGridView2.Rows)
            {
                if(r.Cells[4].Selected == true)
                {
                    string itemname;
                    propertyType = r.Cells[3].Value.ToString();
                    itemname = r.Cells[0].Value.ToString();
                    var i = (from x in ent.Items
                             where x.Title.Equals(itemname) select new
                             {
                                 x.ID
                             }

                     ).FirstOrDefault();
                    itemID = i.ID;
                    EditForm ef = new EditForm();
                    ef.Show();
                    
                }
                
            }
            
        }

        private void addListingBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddForm af = new AddForm();
            af.Show();
        }

        private void logoutBtn_Click(object sender, EventArgs e)
        {
            File.WriteAllText("session.txt","");
            this.Hide();
            
        }
    }
}
