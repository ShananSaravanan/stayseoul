﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaySeoul_Session1
{
    public partial class AddForm : Form
    {
        Session1Entities ent = new Session1Entities();
        public AddForm()
        {
            InitializeComponent();
        }

        public bool TabSellectingAllowed { get; private set; }

        private void AddForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'session1DataSet.Attractions' table. You can move, or remove it, as needed.
            this.attractionsTableAdapter.Fill(this.session1DataSet.Attractions);
            // TODO: This line of code loads data into the 'session1DataSet.Areas' table. You can move, or remove it, as needed.
            this.areasTableAdapter.Fill(this.session1DataSet.Areas);
            // TODO: This line of code loads data into the 'session1DataSet.ItemTypes' table. You can move, or remove it, as needed.
            this.itemTypesTableAdapter.Fill(this.session1DataSet.ItemTypes);
            TabSellectingAllowed = false;
            var x = (from i in ent.Amenities
                     select new
                     {
                         i.Name
                     }
            );
            foreach (var j in x)
            {
                dataGridView1.Rows.Add(j.Name);
            }
            var z = (from u in ent.Areas
                     join j in ent.Attractions on u.ID equals j.AreaID
                     select new
                     {
                         u.Name,
                         attractionname = j.Name
                     });
            foreach (var i in z)
            {
                dataGridView2.Rows.Add(i.attractionname, i.Name);
            }
        }

        private void nextBtn_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex == 0)
            {
                TabSellectingAllowed = true;
                tabControl1.SelectedIndex = 1;
                TabSellectingAllowed = false;
            }
            else if (tabControl1.SelectedIndex == 1)
            {
                TabSellectingAllowed = true;
                tabControl1.SelectedIndex = 2;
                TabSellectingAllowed = false;
                nextBtn.Hide();
                cancelBtn.Hide();
                finishBtn.Show();
            }
        }

        private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (TabSellectingAllowed == false)
            {
                e.Cancel = true;
            }
            else
            {
                e.Cancel = false;
            }
        }

        private void finishBtn_Click(object sender, EventArgs e)
        {
            var newItem = new Item();
            newItem.ID = ent.Items.Count() + 1;
            string[] amenityList = new string[15];
            string[] attractionList = new string[150];
            int count = 0;
            int count1 = 0;
            foreach (DataGridViewRow r in dataGridView1.Rows)
            {
                if (Convert.ToBoolean(r.Cells[1].Value) == true)
                {
                    amenityList[count] = r.Cells[0].Value.ToString();
                    count++;
                }

            }
            foreach (DataGridViewRow rows in dataGridView2.Rows)
            {
                if (rows.Cells[2].Value != null || rows.Cells[3].Value != null || rows.Cells[4].Value != null)
                {
                    attractionList[count1] = rows.Cells[0].Value.ToString();
                }
            }
            foreach (var t in attractionList.Where(x => x != null))
            {
                Guid g = Guid.NewGuid();
                var at = (from q in ent.Attractions
                          where q.Name.Equals(t)
                          select new
                          {
                              q.ID
                          }).FirstOrDefault();
                foreach (DataGridViewRow r in dataGridView2.Rows)
                {
                    if (r.Cells[0].Value.ToString().Equals(t))
                    {
                        var attraction = new ItemAttraction();
                        attraction.ID = ent.ItemAttractions.Count() + 1;
                        attraction.ItemID = newItem.ID;
                        attraction.AttractionID = at.ID;
                        attraction.GUID = g;
                        if(r.Cells[2].Value != null)
                        {
                            attraction.Distance = decimal.Parse(r.Cells[2].Value.ToString());
                           
                        }
                        if(r.Cells[3].Value != null)
                        {
                            attraction.DurationOnFoot = long.Parse(r.Cells[3].Value.ToString());
                           
                        }
                        if(r.Cells[4].Value != null)
                        {
                            attraction.DurationByCar = long.Parse(r.Cells[4].Value.ToString());
                        }
                        ent.ItemAttractions.Add(attraction);

                    }
                }
                foreach (var am in amenityList.Where(x => x != null))
                {
                    Guid gu = Guid.NewGuid();
                    var aid = (from j in ent.Amenities
                               where j.Name.ToString().Equals(am)
                               select new
                               {
                                   j.ID
                               }).FirstOrDefault();
                    var a = new ItemAmenity();
                    a.ID = ent.ItemAmenities.Count() + 1;
                    a.GUID = gu;
                    a.ItemID = newItem.ID;
                    a.AmenityID = aid.ID;
                    ent.ItemAmenities.Add(a);
                }

                var o = (from p in ent.ItemTypes
                         where p.Name.ToString().Equals(typeCmbBox.Text)
                         select new
                         {
                             p.ID
                         }).FirstOrDefault();
                var i = (from k in ent.Areas
                         where k.Name.ToString().Equals(comboBox1.Text)
                         select new
                         {
                             k.ID
                         }).FirstOrDefault();
                Guid guid = Guid.NewGuid();
                newItem.GUID = guid;
                newItem.UserID = long.Parse(StaySeoul_Session1.Menu.userID.ToString());
                newItem.Title = titleTxtField.Text;
                newItem.Description = descTxtField.Text;
                newItem.Capacity = (int)capacity.Value;
                newItem.NumberOfBathrooms = (int)nBathRooms.Value;
                newItem.NumberOfBedrooms = (int)nBedRooms.Value;
                newItem.NumberOfBeds = (int)nBeds.Value;
                newItem.AreaID = i.ID;
                newItem.ItemTypeID = o.ID;
                newItem.ExactAddress = eAddressTxtField.Text;
                newItem.ApproximateAddress = aAdressTxtField.Text;
                newItem.HostRules = rulesTxtField.Text;
                newItem.MinimumNights = (int)min.Value;
                newItem.MaximumNights = (int)max.Value;
                ent.Items.Add(newItem);
                MessageBox.Show("Success");
                ent.SaveChanges();
            }
            this.Hide();
            Menu m = new Menu();
            m.Show();
        }
    }
}
