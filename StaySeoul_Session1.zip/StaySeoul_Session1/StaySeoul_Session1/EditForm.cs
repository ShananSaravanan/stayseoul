﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaySeoul_Session1
{
    public partial class EditForm : Form
    {
        Session1Entities ent = new Session1Entities();
        

        public bool TabSelectingAllowed { get; private set; }

        public EditForm()
        {
            InitializeComponent();
        }
        public void propertyTypes()
        {
            var t = (from i in ent.ItemTypes select new
            {
                i.Name
            }
            );
            foreach (var type in t)
            {
                typeCmbBox.Items.Add(type.Name);
            }
        }
        public void importData()
        {

            var data = (from x in ent.Items
                        where x.ID.Equals(StaySeoul_Session1.Menu.itemID)
                        select new
                        {
                            x.Title,
                            x.Capacity,
                            x.ApproximateAddress,
                            x.ExactAddress,
                            x.Description,
                            x.HostRules,
                            x.MinimumNights,
                            x.MaximumNights,
                            x.NumberOfBathrooms,
                            x.NumberOfBedrooms,
                            x.NumberOfBeds
                        }

                        ).FirstOrDefault();
            titleTxtField.Text = data.Title;
            eAddressTxtField.Text = data.ExactAddress;
            aAdressTxtField.Text = data.ApproximateAddress;
            descTxtField.Text = data.Description;
            rulesTxtField.Text = data.HostRules;
            capacity.Value = data.Capacity;
            nBathRooms.Value = data.NumberOfBathrooms;
            nBedRooms.Value = data.NumberOfBedrooms;
            nBeds.Value = data.NumberOfBeds;
            min.Value = data.MinimumNights;
            max.Value = data.MaximumNights;
            typeCmbBox.SelectedText = StaySeoul_Session1.Menu.propertyType.ToString();
        }
        
        public bool checkValues()
        {
            bool isTrue = true;
            if(capacity.Value > 0 || min.Value > 0 || max.Value > 0 || nBeds.Value >0 || nBedRooms.Value > 0  || nBathRooms.Value > 0)
            {
                isTrue = true;
            }
            else
            {
                isTrue = false;
                MessageBox.Show("The values must be more than zero");
            }
            return isTrue;
        }
        public bool checkFields()
        {
            bool isEmpty = true;
            if(string.IsNullOrEmpty(titleTxtField.Text) == true || string.IsNullOrEmpty(aAdressTxtField.Text) == true || string.IsNullOrEmpty(eAddressTxtField.Text) == true || string.IsNullOrEmpty(descTxtField.Text) == true
                || string.IsNullOrEmpty(rulesTxtField.Text) == true) {
                isEmpty = true;
                MessageBox.Show("All fields must be filled in!");
            }
            else
            {
                isEmpty = false;
            }
            return isEmpty;
        }
        public bool checkMax()
        {
            bool isBig = true;
            if(min.Value <= max.Value)
            {
                isBig = false;
            }
            else
            {
                isBig = true;
                MessageBox.Show("Minimum reservation value must be smaller than or equal to maximum reservation value");
            }
            return isBig;
        }
        private void EditForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'session1DataSet.Amenities' table. You can move, or remove it, as needed.
            this.amenitiesTableAdapter.Fill(this.session1DataSet.Amenities);
            TabSelectingAllowed = false;
            propertyTypes();
            importData();
              
            finishBtn.Hide();

            var q = (from y in ent.Amenities
                     select new
                     {
                         y.Name
                     }
                        );
            foreach(var item in q)
            {
                dataGridView1.Rows.Add(item.Name);
            }
            var a = (from x in ent.ItemAmenities
                     join i in ent.Amenities on x.AmenityID equals i.ID
                     where x.ItemID.Equals(StaySeoul_Session1.Menu.itemID)
                     select new
                     {
                         i.Name
                     }
                     );
            
            foreach (var amenitylist in a)
            {
                
                foreach(DataGridViewRow r in dataGridView1.Rows)
                {
                    if (r.Cells[0].Value.ToString().Equals(amenitylist.Name))
                    {
                        r.Cells[1].Value = true;
                    }
                    

                }
            }
            
            var z = (from f in ent.Attractions
                     join g in ent.Areas on f.AreaID equals g.ID
                     select new
                     {
                        f.Name,
                        areaname = g.Name
                     }
            );
            foreach(var attraction in z)
            {
                dataGridView2.Rows.Add(attraction.Name,attraction.areaname);
            }
            var m = (from i in ent.ItemAttractions
                     join k in ent.Attractions on i.AttractionID equals k.ID
                     where i.ItemID.Equals(StaySeoul_Session1.Menu.itemID)
                     select new
                     {
                        i.Distance,
                        i.DurationOnFoot,
                        i.DurationByCar,
                        k.Name
                     }
            );
            foreach (var attraction in m)
            {
                
                foreach (DataGridViewRow rows in dataGridView2.Rows)
                {

                    if (rows.Cells[0].Value.ToString().Equals(attraction.Name))
                    {
                        rows.Cells[2].Value = attraction.Distance;
                        rows.Cells[3].Value = attraction.DurationOnFoot;
                        rows.Cells[4].Value = attraction.DurationByCar;
                    }
                }
            }
            
        }

        private void nextBtn_Click(object sender, EventArgs e)
        {
            if (checkValues() && !checkFields() && !checkMax())
            {
                if (tabControl1.SelectedIndex == 0)
                {
                    TabSelectingAllowed = true;
                    tabControl1.SelectedIndex = 1;
                    TabSelectingAllowed = false;
                }
                else if (tabControl1.SelectedIndex == 1)
                {
                    TabSelectingAllowed = true;
                    tabControl1.SelectedIndex = 2;
                    TabSelectingAllowed = false;
                    nextBtn.Hide();
                    cancelBtn.Hide();
                    finishBtn.Show();
                }
            }
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if(TabSelectingAllowed == false)
            {
                e.Cancel = true;
            }
            else
            {
                e.Cancel= false;
            }
        }

        private void finishBtn_Click(object sender, EventArgs e)
        {
            string[] amenityList = new string[15];
            string[] attractionList = new string[150];
            int count = 0;
            int count1 = 0;
            foreach (DataGridViewRow r in dataGridView1.Rows)
            {

                if (Convert.ToBoolean(r.Cells[1].Value) == true)
                {
                    amenityList[count] = dataGridView1[0, r.Index].Value.ToString();
                    count++;
                }
            }
            foreach (DataGridViewRow r in dataGridView2.Rows)
            {

                if(r.Cells[2].Value != null || r.Cells[3].Value != null || r.Cells[4].Value != null)
                {
                    attractionList[count1] = dataGridView2[0, r.Index].Value.ToString();
                    count1++;
                }
            }
            var itemtype = (from i in ent.ItemTypes
                            where i.Name.ToString().Equals(typeCmbBox.Text)
                            select new
                            {
                                i.ID
                            }

                            ).FirstOrDefault();
            var am = ent.ItemAmenities.Where(x => x.ItemID == StaySeoul_Session1.Menu.itemID);
            foreach (var a in am)
            {
                ent.ItemAmenities.Remove(a);
            }
            
            foreach(var x in amenityList.Where(x=> x!=null))
            {
                
                var amenity = (from p in ent.Amenities where p.Name.ToString().Equals(x) select new
                {
                    p.ID
                }
                ).FirstOrDefault();
                
                Guid guid = Guid.NewGuid();
                ItemAmenity ia = new ItemAmenity();
                ia.ID = ent.ItemAmenities.Count() + 1;
                ia.GUID = guid;
                ia.ItemID = StaySeoul_Session1.Menu.itemID;
                ia.AmenityID = amenity.ID;
                ent.ItemAmenities.Add(ia);
                ent.SaveChanges();
            }
            var re = ent.ItemAttractions.Where(x => x.ItemID == StaySeoul_Session1.Menu.itemID);
            foreach (var r in re)
            {
                ent.ItemAttractions.Remove(r);
            }
            foreach (var i in attractionList.Where(x=> x != null))
            {
                var attractionID = (from r in ent.Attractions
                                    where r.Name.ToString().Equals(i)
                                    select new
                                    {
                                        r.ID
                                    }
                ).FirstOrDefault();
                foreach(DataGridViewRow r in dataGridView2.Rows)
                {
                    if (r.Cells[0].Value.ToString().Equals(i))
                    {
                        Guid guid = Guid.NewGuid();
                        ItemAttraction at = new ItemAttraction();
                        at.ID = ent.Attractions.Count() + 1;
                        at.GUID = guid;
                        at.ItemID = StaySeoul_Session1.Menu.itemID;
                        at.AttractionID = attractionID.ID;
                        at.Distance = decimal.Parse(r.Cells[2].Value.ToString());
                        at.DurationOnFoot = long.Parse(r.Cells[3].Value.ToString());
                        at.DurationByCar = long.Parse(r.Cells[4].Value.ToString());
                        ent.ItemAttractions.Add(at);
                    }
                }
                ent.SaveChanges();
            }
            
            var item = ent.Items.FirstOrDefault(x=>x.ID == StaySeoul_Session1.Menu.itemID);
            item.ItemTypeID = itemtype.ID;
            item.Title = titleTxtField.Text;
            item.Capacity = (int)capacity.Value;
            item.NumberOfBathrooms = (int)nBathRooms.Value;
            item.NumberOfBedrooms = (int)nBedRooms.Value;
            item.NumberOfBeds = (int)nBedRooms.Value;
            item.ExactAddress = eAddressTxtField.Text;
            item.ApproximateAddress = aAdressTxtField.Text;
            item.Description = descTxtField.Text;
            item.HostRules = rulesTxtField.Text;
            item.MinimumNights = (int)min.Value;
            item.MaximumNights = (int)max.Value;
            ent.SaveChanges();
            MessageBox.Show("Records Updated Successfully!");
            this.Hide();
        }
    }
}
